// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resample to 1s bars"); }
int main(){
  announce();
  return lionss_run_workload("tickresample");
}
