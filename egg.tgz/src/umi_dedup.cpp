// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Collapse UMI duplicates\n", stdout);
  return lionss_run_workload("umi_dedup");
}
