// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Coordinate-sort records"); }
int main(){
  announce();
  return lionss_run_workload("sam_sort");
}
